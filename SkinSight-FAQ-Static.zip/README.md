# SkinSight: camera preview + skincare FAQs

This is a lightweight, static website. It has no AI, backend, external libraries, photo uploads, or photo storage. The camera only displays a local preview; the FAQs are prewritten educational answers.

## Use with GitHub Pages

1. Upload `index.html` to the root of your GitHub repository (the first folder shown on the repository Code tab).
2. In GitHub, open **Settings → Pages**. Select **Deploy from a branch**, choose your main branch and `/(root)`, then save.
3. Open the HTTPS Pages link GitHub provides. Press **Start camera** and allow camera access, or choose a photo for a local preview.

Camera access requires a secure context, such as GitHub Pages HTTPS or `localhost`. The photo is not analyzed, sent anywhere, or saved by this page.
